import json
import os
import glob
import argparse
import torch
import torchvision
import numpy
from tqdm import tqdm
import pyro
import pandas
from pyro.infer import SVI, Trace_ELBO, TraceGraph_ELBO
import datetime
import pickle
from sklearn.model_selection import train_test_split
from sklearn import metrics
from pyro.distributions import Normal, Categorical, LogNormal, Bernoulli
from PIL import Image
from matplotlib import pyplot, rc

#torch.manual_seed(0)

font = {'family' : 'Times',
        'weight' : 'normal',
        'size'   : 16}

rc('font', **font)

'''
class BCNN(nn.Module):
	def __init__(self, input_size, hidden_size, output_size):
		super(BCNN, self).__init__()
		self.conv1 = nn.Conv2d(in_channels = 3, out_channels = 6, kernel_size = 5)
		self.pool = nn.MaxPool2d(2, 2)
		self.conv2 = nn.Conv2d(6, 16, 5)		
		self.fc1 = nn.Linear(input_size, hidden_size)
		self.out = nn.Linear(hidden_size, output_size)
	def forward(self, x):
		x = self.pool(F.relu(self.conv1(x)))
		x = self.pool(F.relu(self.conv2(x)))
		x = F.sigmoid(torch.flatten(x, 1)) # flatten all dimensions except batch	
		x = self.fc1(x)
		x = F.relu(x)
		x = self.out(x)
		return x
'''

class BCNN(torch.nn.Module):
	def __init__(self, mlp_d1, mlp_d2, mlp_d3):
		super(BCNN, self).__init__()
		self.conv1 = torch.nn.Conv2d(in_channels = 3, out_channels = 16, kernel_size = 5)
		self.conv2 = torch.nn.Conv2d(16, 24, 5)
		self.conv3 = torch.nn.Conv2d(24, 32, 5)
		self.pool1 = torch.nn.AvgPool2d(4, stride = 2)		
		self.pool2 = torch.nn.AvgPool2d(4, stride = 2)
		self.pool3 = torch.nn.AvgPool2d(4, stride = 2)		
		self.bn1 = torch.nn.BatchNorm2d(32)
		self.fc1 = torch.nn.Linear(mlp_d1, mlp_d2)
		self.out = torch.nn.Linear(mlp_d2, mlp_d3)
		self.act = torch.nn.Sigmoid()
		self.dp = torch.nn.Dropout(p=0.2)
	def forward(self, x):
		x = self.act(self.conv1(x));
		x = self.pool1(x);
		x = self.act(self.conv2(x));
		x = self.pool2(x);		
		x = self.act(self.conv3(x));
		x = self.pool3(x);
		x = self.bn1(x);		
		x = torch.flatten(x, 1) # flatten all dimensions except batch
		x = self.dp(x)	
		x = self.fc1(x)
		x = self.out(x)
		return x

def model(x_data, y_data, Model):
	fc1w_prior = Normal(loc=torch.ones_like(Model.fc1.weight), scale=torch.ones_like(Model.fc1.weight))
	fc1b_prior = Normal(loc=torch.ones_like(Model.fc1.bias), scale=torch.ones_like(Model.fc1.bias))
	outw_prior = Normal(loc=torch.ones_like(Model.out.weight), scale=torch.ones_like(Model.out.weight))
	outb_prior = Normal(loc=torch.ones_like(Model.out.bias), scale=torch.ones_like(Model.out.bias))
	priors = {'fc1.weight': fc1w_prior, 'fc1.bias': fc1b_prior,  'out.weight': outw_prior, 'out.bias': outb_prior}
	# lift module 
	lifted_module = pyro.random_module("module", Model, priors)
	#lifted_module = pyro.nn.module("module", Model, priors)
	lifted_reg_model = lifted_module()
	ActFunc = torch.nn.LogSoftmax(dim=1);
	yhat = ActFunc(lifted_reg_model(x_data))
	pyro.sample("data_dist", Normal(outw_prior.loc, outw_prior.scale))
	#pyro.sample("sigma", LogNormal(0.0, 1.0))
	#event_dim = max(lhat.dim() - 1, y_data.dim())
	#pyro.sample("obs", Categorical(logits=lhat).to_event(event_dim), obs=y_data)

def guide(x_data, y_data, Model):
	softplus = torch.nn.Softplus()
	# Input layer weight distribution priors
	fc1w_mu = torch.randn_like(Model.fc1.weight)
	fc1w_sigma = torch.randn_like(Model.fc1.weight)
	fc1w_mu_param = pyro.param("fc1w_mu", fc1w_mu)
	fc1w_sigma_param = softplus(pyro.param("fc1w_sigma", fc1w_sigma))
	fc1w_prior = Normal(loc=fc1w_mu_param, scale=fc1w_sigma_param)
	# Input layer bias distribution priors
	fc1b_mu = torch.randn_like(Model.fc1.bias)
	fc1b_sigma = torch.randn_like(Model.fc1.bias)
	fc1b_mu_param = pyro.param("fc1b_mu", fc1b_mu)
	fc1b_sigma_param = softplus(pyro.param("fc1b_sigma", fc1b_sigma))
	fc1b_prior = Normal(loc=fc1b_mu_param, scale=fc1b_sigma_param)
	# Output layer weight distribution priors
	outw_mu = torch.randn_like(Model.out.weight)
	outw_sigma = torch.randn_like(Model.out.weight)
	outw_mu_param = pyro.param("outw_mu", outw_mu)
	outw_sigma_param = softplus(pyro.param("outw_sigma", outw_sigma))
	outw_prior = Normal(loc=outw_mu_param, scale=outw_sigma_param).independent(1)
	# Output layer bias distribution priors
	outb_mu = torch.randn_like(Model.out.bias)
	outb_sigma = torch.randn_like(Model.out.bias)
	outb_mu_param = pyro.param("outb_mu", outb_mu)
	outb_sigma_param = softplus(pyro.param("outb_sigma", outb_sigma))
	outb_prior = Normal(loc=outb_mu_param, scale=outb_sigma_param)
	priors = {'fc1.weight': fc1w_prior, 'fc1.bias': fc1b_prior, 'out.weight': outw_prior, 'out.bias': outb_prior}
	lifted_module = pyro.random_module("module", Model, priors)
	return lifted_module()

def predict(X, n_samples, Model, device):
	sampled_models = [guide(None, None,Model) for _ in range(n_samples)]
	Y_hat = [model(X).data for model in sampled_models]
	mean = torch.mean(torch.stack(Y_hat), 0)
	Y_hat = numpy.argmax(mean.cpu().numpy(), axis=1)
	Y_hat = torch.tensor(Y_hat, dtype=torch.float32);
	Y_hat = Y_hat.to(device);
	return Y_hat
	
def posterior(X, n_samples, Model, device):
	sampled_models = [guide(None, None, Model) for _ in range(n_samples)]
	Y_hat = [model(X).data for model in sampled_models]
	mean = torch.mean(torch.stack(Y_hat), 0)
	Y_hat = numpy.max(mean.cpu().numpy(), axis=1)
	Y_hat = torch.tensor(Y_hat, dtype=torch.float32);
	Y_hat = Y_hat.to(device);
	return Y_hat

def GenerateDataset(Options):

	data_transforms = torchvision.transforms.Compose([
        torchvision.transforms.RandomHorizontalFlip(),    
        torchvision.transforms.Resize(256),
        torchvision.transforms.CenterCrop(224),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]);

	Dataset = torchvision.datasets.ImageFolder(Options.DatasetPath, data_transforms);

	if Options.Split == 0: # implies reading the full set
		DataLoader = torch.utils.data.DataLoader(Dataset, batch_size = Options.BS, shuffle = True, num_workers = 2);
	else:
		train_idx, val_idx = train_test_split(list(range(len(Dataset))), train_size = Options.Split);
	
		train_dataset = torch.utils.data.Subset(Dataset, train_idx);
		test_dataset = torch.utils.data.Subset(Dataset, val_idx);

		train_loader = torch.utils.data.DataLoader(train_dataset, batch_size = Options.BS, shuffle = True, num_workers = 2);
		test_loader = torch.utils.data.DataLoader(test_dataset, batch_size = Options.BS, shuffle = True, num_workers = 2);
		
		if Options.Command == "TrainModel":
			DataLoader = train_loader;
		else:
			DataLoader = test_loader;

	return DataLoader


def Score(X_train, n_samples, Model, device):
	Y_hat = posterior(X_train, n_samples, Model);
	score = torch.sum(Y_hat) / len(Y_hat);
	return score.cpu().detach().numpy();


def TrainModel(Options):
		
	DataLoader = GenerateDataset(Options);

	optimizer = torch.optim.SGD
	#optimizer = torch.optim.BCELoss
	scheduler = pyro.optim.ExponentialLR({'optimizer': optimizer, 'optim_args': {'lr': Options.LR}, 'gamma': 0.1})
	svi = SVI(model, guide, scheduler, loss=TraceGraph_ELBO())
	n_samples = Options.n_samples;

	#optimizer = pyro.optim.SGD({"lr": args.LR})
	#svi = SVI(model, guide, optimizer, loss=TraceGraph_ELBO())
	
	device = torch.device("cuda:" + Options.GPU);
	#Model = BCNN(44944, 512, 1)
	Model = BCNN(15488, 512, 1)
	Model = Model.to(device);
	#Model = nn.DataParallel(Model); # multiGPU not supported

	print('\nTraining ... ')
	
	print(device)

	EL = numpy.array([],dtype = object);
	ES = numpy.array([],dtype = object);

	for epoch in range(Options.Epochs):
		print("Epoch {}/{}\n".format(epoch, Options.Epochs - 1));
		
		EpochLoss = 0
		EpochScore = 0
		Posterior = numpy.array([],dtype = object)
		
		for x, y in (pbar := tqdm(DataLoader) ):
			x = x.to(device)
			y = y.to(device)
			loss = svi.step(x, y, Model)	/  len(x)
			p = posterior(x, n_samples, Model, device).cpu().detach().numpy();
			Posterior = numpy.append(Posterior, p);
			score = p.sum() / len(p)
			mssg = "Epoch: {epoch:4d}  BatchLoss: {loss:3.4f}   BatchScore: {score:3.3f}".format(epoch = epoch, loss = loss, score = score)
			EpochLoss += loss
			EpochScore += score
			pbar.set_description(mssg)
		EL = numpy.append(EL, EpochLoss);
		ES = numpy.append(ES, EpochScore);

		print("Epoch Loss: %f \t Epoch Score : %f" %(EpochLoss, EpochScore))

	ModelPath = Options.ModelPath;

	newPath = str(datetime.datetime.now());
	newPath = newPath.split(".")[0];
	newPath = newPath.replace(" ", "_");
	newPath = newPath.replace(":", "_");
	newPath = newPath.replace("-", "_");
	ModelPath = ModelPath.replace("<date>", newPath);
		
	os.system("mkdir -p %s" %(ModelPath) );
		
	print("\nSaving model on path %s \n" %(ModelPath))
		
	torch.save(Model.state_dict(), ModelPath + "/Model.pth")

	Parms = pyro.params.param_store.ParamStoreDict();
	Parms.save(ModelPath + "/Model.save");
	
	
	Sesion = {
		"NameSpace" : str(Options),
		"EpochLoss" : list(EL),
		"EpochScore" : list(ES),
		"Parameters" : count_parameters(Model),		
		"Posterior" : list(Posterior),
	}
	
	json_obj = json.dumps(Sesion, indent = 3)
	
	with open(ModelPath + "/Model.json", "w") as fid:
		fid.write(json_obj)

def count_parameters(model):
	parms = sum(p.numel() for p in model.parameters() if p.requires_grad);
	return parms		
	
def TestModel(Options):
	DataLoader = GenerateDataset(Options);
	n_samples = Options.n_samples;
	#Model = BCNN(44944, 512, 1);
	Model = BCNN(15488, 512, 1);
	device = torch.device("cuda:" + Options.GPU);
	Model.load_state_dict(torch.load(Options.ModelPath + "Model.pth"))
	Model.eval()
	Model = Model.to(device);
	Parms = pyro.params.param_store.ParamStoreDict();
	Parms.load(Options.ModelPath + "Model.save")
	
	Posterior = numpy.array([],dtype = object)
	
	for x, y in tqdm(DataLoader, total = len(DataLoader), desc = "Testing Batch"  ):
		x = x.to(device)
		y = y.to(device)
		Posterior = numpy.append(Posterior, posterior(x, n_samples, Model, device).cpu().detach().numpy());
	
	print("\nSaving sesion %s \n" %(Options.ModelPath + Options.OutFile))
	
	Sesion = {
		"NameSpace" : str(Options),
		"Posterior" : list(Posterior),
	}
	
	json_obj = json.dumps(Sesion, indent = 3)
	
	with open(Options.ModelPath + Options.OutFile, "w") as fid:
		fid.write(json_obj)	
	

def ReadPredictions(File):
	fid = open(File);
	data = json.load(fid);
	fid.close();
	x = numpy.asarray( data.get("Posterior") );
	return x;


def RankModelROC(Options):

	pyplot.figure(figsize = [9, 6])
	
	y_hat_real = -ReadPredictions(Options.JSONReal);
	y_hat_fake = -ReadPredictions(Options.JSONFake);

	y_real = numpy.ones(y_hat_real.size);
	y_fake = numpy.zeros(y_hat_fake.size);
		
	y_hat = numpy.concatenate([ y_hat_real , y_hat_fake ]);
	y = numpy.concatenate( [y_real, y_fake] );

	fpr, tpr, _ = metrics.roc_curve(y, y_hat);

	pyplot.plot(fpr, tpr)
		
	pyplot.ylabel('True Positive Rate')
	pyplot.xlabel('False Positive Rate')
	pyplot.savefig("FIG_ROC.png",  bbox_inches='tight')

	
def RankModelErrorRate(Options):

	gamma = Options.gamma.split(":");
	gamma = [float(g) for g in gamma];
	
	pyplot.figure(figsize = [9, 6])
	
	for g in numpy.linspace( gamma[0], gamma[1], int(gamma[2])):
		y_hat_real = ReadPredictions(Options.JSONReal, g);
		y_hat_fake = ReadPredictions(Options.JSONFake, g);

		y_real = numpy.ones(y_hat_real.size);
		y_fake = numpy.zeros(y_hat_fake.size);
		
		y_hat = numpy.concatenate([ y_hat_real , y_hat_fake ]);
		y = numpy.concatenate( [y_real, y_fake] );

		fpr, tpr, _ = metrics.roc_curve(y, y_hat);

		#create ROC curve
		pyplot.plot(fpr, tpr, label = "gamma : %0.3f" %(g) )
		
	pyplot.legend(loc = "lower right")
	pyplot.ylabel('True Positive Rate')
	pyplot.xlabel('False Positive Rate')
	pyplot.savefig("FIG_errROC.png",  bbox_inches='tight')
	

def VisualizePredictions(Options):

	pyplot.figure(figsize = [16, 9])

	for File in glob.glob(Options.JSONfilesPath + "*.json"):
		f = open(File);
		File = File.split("/")[-1]
		File = File.split(".")[0]
		data = json.load(f);
		f.close();
		x = data.get("Posterior"); # referred as p out of the CBN
		x = numpy.asarray(x[0:10000]) - 5000;
		x = -x
		pyplot.plot(x, label  = File, linestyle = "None", marker = ".", alpha = 0.7, markersize = 0.5);
		pyplot.yscale("log")
		pyplot.xscale("log")
		
	#pyplot.title("Posterior CBN");
	pyplot.legend(loc = "lower left", markerscale = 20)
	pyplot.xlabel("Test Samples")
	pyplot.ylabel("Posterior")
	
	
	pyplot.savefig("FIG_posteriors.png",  bbox_inches='tight')

	

def TestSample(Options):
	data_transforms = torchvision.transforms.Compose([
        torchvision.transforms.RandomHorizontalFlip(),    
        torchvision.transforms.Resize(256),
        torchvision.transforms.CenterCrop(224),
        torchvision.transforms.ToTensor(),
        torchvision.transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ]);

	n_samples = Options.n_samples;
	Model = BCNN(44944, 512, 1);
	Model.device = torch.device("cuda:" + Options.GPU);
	Model.load_state_dict(torch.load(Options.ModelFile))
	Model.eval()
	Model = Model.to(Model.device);
	Parms = pyro.params.param_store.ParamStoreDict();
	ParmsFile = Options.ModelFile.replace(".pth",".save");
	Parms.load(ParmsFile)

	Is = Image.open(Options.ImagePath);
	x = torch.autograd.Variable(data_transforms(Is).unsqueeze(0));
	x = x.to(Model.device)
	Is.close();
	p = posterior(x, n_samples, Model).cpu().detach().numpy();
	print("Image : %s => Posterior : %f" %(Options.ImagePath, p) );
	
def RandomPolinomia(DF):

	#DF = pandas.read_csv("/home/re8is/Dropbox/BayesianFusion/DATA/FusedDataset.csv")

	for k in range(0, len(DF.columns)-1):
		Xk = DF.iloc[:,k];
		n = numpy.random.randint(low = 1, high = 4);
		p = 0.25 * numpy.random.randint(low = 0, high = 4, size = n);
		Yk = numpy.polyval(p, Xk);
		DF.iloc[:,k] = Yk

	return DF


