import torch.nn as nn
import torch.nn.functional as F
from pyro.distributions import Normal, Categorical
import torch
import pyro
import numpy

class NN(nn.Module):
	def __init__(self, input_size, hidden_size, output_size):
		super(NN, self).__init__()
		self.conv1 = nn.Conv2d(in_channels = 3, out_channels = 6, kernel_size = 5)
		self.pool = nn.MaxPool2d(2, 2)
		self.conv2 = nn.Conv2d(6, 16, 5)		
		self.fc1 = nn.Linear(input_size, hidden_size)
		self.out = nn.Linear(hidden_size, output_size)
	def forward(self, x):
		x = self.pool(F.relu(self.conv1(x)))
		x = self.pool(F.relu(self.conv2(x)))
		x = F.relu(torch.flatten(x, 1)) # flatten all dimensions except batch	
		x = self.fc1(x)
		x = F.relu(x)
		x = self.out(x)
		return x

net = NN(44944, 512, 2)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
net = net.to(device);
try:
	net = nn.DataParallel(net);
	net.device = device
	print("\n" + "\033[1;33m" + "Using multi-GPU support" + "\033[0m" + "\n");
except:
	print("");

def model(x_data, y_data):
	fc1w_prior = Normal(loc=torch.ones_like(net.module.fc1.weight), scale=torch.ones_like(net.module.fc1.weight))
	fc1b_prior = Normal(loc=torch.ones_like(net.module.fc1.bias), scale=torch.ones_like(net.module.fc1.bias))
	outw_prior = Normal(loc=torch.ones_like(net.module.out.weight), scale=torch.ones_like(net.module.out.weight))
	outb_prior = Normal(loc=torch.ones_like(net.module.out.bias), scale=torch.ones_like(net.module.out.bias))
	priors = {'fc1.weight': fc1w_prior, 'fc1.bias': fc1b_prior,  'out.weight': outw_prior, 'out.bias': outb_prior}
	# lift module 
	lifted_module = pyro.random_module("module", net.module, priors)
	#lifted_module = pyro.nn.module("module", net, priors)
	lifted_reg_model = lifted_module()
	ActFunc = nn.LogSoftmax(dim=1);
	lhat = ActFunc(lifted_reg_model(x_data))
	pyro.sample("obs", Categorical(logits=lhat), obs=y_data)
	#event_dim = max(lhat.dim() - 1, y_data.dim())
	#pyro.sample("obs", Categorical(logits=lhat).to_event(event_dim), obs=y_data)

def guide(x_data, y_data):
	softplus = torch.nn.Softplus()
	# Input layer weight distribution priors
	fc1w_mu = torch.randn_like(net.module.fc1.weight)
	fc1w_sigma = torch.randn_like(net.module.fc1.weight)
	fc1w_mu_param = pyro.param("fc1w_mu", fc1w_mu)
	fc1w_sigma_param = softplus(pyro.param("fc1w_sigma", fc1w_sigma))
	fc1w_prior = Normal(loc=fc1w_mu_param, scale=fc1w_sigma_param)
	# Input layer bias distribution priors
	fc1b_mu = torch.randn_like(net.module.fc1.bias)
	fc1b_sigma = torch.randn_like(net.module.fc1.bias)
	fc1b_mu_param = pyro.param("fc1b_mu", fc1b_mu)
	fc1b_sigma_param = softplus(pyro.param("fc1b_sigma", fc1b_sigma))
	fc1b_prior = Normal(loc=fc1b_mu_param, scale=fc1b_sigma_param)
	# Output layer weight distribution priors
	outw_mu = torch.randn_like(net.module.out.weight)
	outw_sigma = torch.randn_like(net.module.out.weight)
	outw_mu_param = pyro.param("outw_mu", outw_mu)
	outw_sigma_param = softplus(pyro.param("outw_sigma", outw_sigma))
	outw_prior = Normal(loc=outw_mu_param, scale=outw_sigma_param).independent(1)
	# Output layer bias distribution priors
	outb_mu = torch.randn_like(net.module.out.bias)
	outb_sigma = torch.randn_like(net.module.out.bias)
	outb_mu_param = pyro.param("outb_mu", outb_mu)
	outb_sigma_param = softplus(pyro.param("outb_sigma", outb_sigma))
	outb_prior = Normal(loc=outb_mu_param, scale=outb_sigma_param)
	priors = {'fc1.weight': fc1w_prior, 'fc1.bias': fc1b_prior, 'out.weight': outw_prior, 'out.bias': outb_prior}
	lifted_module = pyro.random_module("module", net.module, priors)
	return lifted_module()

def predict(X, device, dbn_samples):
	sampled_models = [guide(None, None) for _ in range(dbn_samples)]
	Y_hat = [model(X).data for model in sampled_models]
	mean = torch.mean(torch.stack(Y_hat), 0)
	Y_hat = numpy.argmax(mean.cpu().numpy(), axis=1)
	Y_hat = torch.tensor(Y_hat, dtype=torch.float32);
	Y_hat = Y_hat.to(device);
	return Y_hat
	
def posterior(X, device, dbn_samples):
	sampled_models = [guide(None, None) for _ in range(dbn_samples)]
	Y_hat = [model(X).data for model in sampled_models]
	mean = torch.mean(torch.stack(Y_hat), 0)
	Y_hat = numpy.max(mean.cpu().numpy(), axis=1)
	Y_hat = torch.tensor(Y_hat, dtype=torch.float32);
	Y_hat = Y_hat.to(device);
	return Y_hat
