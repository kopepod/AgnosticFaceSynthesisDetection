import LIB_BCNN, argparse, datetime

def main():
	parser = argparse.ArgumentParser(
	"Fake Synthesis Detection via Bayesian CNN", 
	description = "This code is meant to evaluate face synthesis detection from unseen samples");
	subparsers = parser.add_subparsers(title = "Command", dest = "Command");

	subparser = subparsers.add_parser("TrainModel",  description = "This code trains a model from unlabeled data");
	subparser.add_argument("--Epochs", type = int, default = 10, help = "Number of epochs to train the Model");
	subparser.add_argument("--LR", type = float, default = 0.001, help = "Learning Rate");
	subparser.add_argument("--BS", type = int, default = 64, help = "Batch Size");
	subparser.add_argument("--GPU", type = str, default = "0", help = "GPU id device");
	subparser.add_argument("--DatasetPath", type = str, default = "/mnt/TB2/DATASETS/FakesFFHQ_sgan2/Real" , help = "Training samples path");
	subparser.add_argument("--ModelPath", type = str, default = "./MODELS/Model_<date>", help = "Path to save model");
	subparser.add_argument("--n_samples", type = int, default = 50, help = "Number of samples to predict from the Bayesian Model");
	subparser.add_argument("--Split", type = float, default = 0.8, help = "Partition size to train/test the model");
	subparser.set_defaults(func = LIB_BCNN.TrainModel);

	subparser = subparsers.add_parser("TestModel",  description = "This code tests a model from dataset path");
	subparser.add_argument("--DatasetPath", type=str, default = "/mnt/TB2/DATASETS/FakesFFHQ_sgan2/Real", help = "Testing samples path");
	subparser.add_argument("--OutFile", type=str, required = True, help = "JSON file to see the Model's output");
	subparser.add_argument("--ModelPath", type=str, required = True, help = "Path to load the model");
	subparser.add_argument("--n_samples", type=int, default = 50, help = "Number of samples to predict from the Bayesian Model");
	subparser.add_argument("--BS", type=float, default = 64, help = "Batch Size");
	subparser.add_argument("--GPU", type=str, default = "0", help = "GPU id device");
	subparser.add_argument("--Split", type=float, default = 0.8);
	subparser.set_defaults(func = LIB_BCNN.TestModel);

	subparser = subparsers.add_parser("TestSample",  description = "This code tests a sample image");
	subparser.add_argument("--ImagePath", type=str, default = "./SAMPLES/XLGAN/seed0000.png");
	subparser.add_argument("--ModelFile", type=str, default = "./MODELS/Model.pth");
	subparser.add_argument("--n_samples", type=int, default = 50);
	subparser.add_argument("--GPU", type=str, default = "0");
	subparser.set_defaults(func = LIB_BCNN.TestSample);

	subparser = subparsers.add_parser("VisualizePredictions",  description = "This function plots the posteriors");
	subparser.add_argument("--JSONfilesPath", type=str, required = True);
	subparser.set_defaults(func = LIB_BCNN.VisualizePredictions);


	subparser = subparsers.add_parser("RankModelROC",  description = "This function ranks the BCNN model");
	subparser.add_argument("--JSONReal", type=str, required = True, help = "JSON file with predictions of the real dataset");
	subparser.add_argument("--JSONFake", type=str, required = True, help = "JSON file with predictions of the synthetic dataset");
	subparser.set_defaults(func = LIB_BCNN.RankModelROC);

	Options = parser.parse_args();

	print(str(Options) + "\n");

	Options.func(Options);

if __name__ == "__main__":
	print("\n" + "\033[0;32m" + "[start] " + str(datetime.datetime.now()) + "\033[0m" + "\n");
	main();
	print("\n" + "\033[0;32m" + "[end] "+ str(datetime.datetime.now()) + "\033[0m" + "\n");
